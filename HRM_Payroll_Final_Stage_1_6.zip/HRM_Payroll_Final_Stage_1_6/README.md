# HRM & Payroll Demo — Final Stage 1-6

## Cấu trúc
- index.html
- css/style.css
- js/data.js
- js/app.js

## Chạy
Mở `index.html` bằng trình duyệt. Không cần backend.

## Demo accounts
- Employee: employee@company.com / 123456
- Manager: manager@company.com / 123456
- HR: hr@company.com / 123456
- Admin: admin@company.com / 123456

## Luồng demo liên thông
1. Employee tạo PTO -> Manager thấy Pending.
2. Manager duyệt PTO -> HR thấy Approved và có notification.
3. HR tạo OT Schedule -> Employee thấy lịch mới.
4. Employee đăng ký OT -> Manager thấy Pending.
5. Manager duyệt OT -> HR thấy Approved.
6. Payroll và Payslip dùng chung dữ liệu payroll.
7. Admin quản lý user, role/permission, OT/Tax/Insurance config và Audit Log.

Lưu ý: Đây là frontend mock-data demo; reload trang sẽ reset dữ liệu về trạng thái ban đầu.
