const app = document.getElementById("app");
const icons = {
dashboard:"▦", employees:"♙", attendance:"◷", leave:"▤", overtime:"◴",
payroll:"▣", payslip:"▤", reports:"▥", notification:"●", settings:"⚙", logout:"↪",
contract:"▤", onboarding:"✓", users:"♟", roles:"⚙", audit:"▥"
};
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function badge(status){
const map={Active:["badge-green","Active"],Inactive:["badge-gray","Inactive"],Pending:["badge-yellow","Pending"],Approved:["badge-green","Approved"],Rejected:["badge-red","Rejected"],Cancelled:["badge-gray","Cancelled"],Present:["badge-green","Present"],Late:["badge-yellow","Late"],"Early Leave":["badge-red","Early Leave"],Absent:["badge-red","Absent"],Open:["badge-green","Open"],Closed:["badge-gray","Closed"],Paid:["badge-green","Paid"],Draft:["badge-gray","Draft"],Calculated:["badge-yellow","Calculated"],Locked:["badge-gray","Locked"],Completed:["badge-green","Completed"],"In Progress":["badge-yellow","In Progress"]};
const x=map[status]||["badge-gray",status];
return `<span class="badge ${x[0]}">${esc(x[1])}</span>`;
}
function roleLabel(role){return {Employee:"Nhân viên",Manager:"Quản lý",HR:"HR",Admin:"Quản trị viên"}[role]||role;}
function currentEmployee(){return DB.employees.find(e=>e.id===DB.currentUser?.id.replace("USR","EMP")) || DB.employees.find(e=>e.email===DB.currentUser?.email);}
function addAudit(action,target="SYSTEM",result="Success"){DB.auditLogs.unshift({id:"LOG"+String(Date.now()).slice(-6),time:new Date().toLocaleString("vi-VN"),user:DB.currentUser?.name||"System",role:DB.currentUser?.role||"System",action,target,result});}
function addNotification(to,title,message){DB.notifications.unshift({id:"N"+String(Date.now()).slice(-7),to,title,message,time:new Date().toLocaleString("vi-VN"),read:false});}
function shell(content,active="dashboard"){
const role=DB.currentUser?.role||"HR", menu=roleMenus(role);
const unread=DB.notifications.filter(n=>n.to===role&&!n.read).length;
return `<div class="app">
<aside class="sidebar">
<div class="logo"><span>H</span><strong>HRM Portal</strong></div>
<div class="role-chip">${roleLabel(role)}</div>
<div class="menu-title">Workspace</div>
<nav class="nav">${menu.map(([p,i,l])=>`<button class="${active===p?"active":""}" onclick="go('${p}')">${i}<span>${l}</span></button>`).join("")}</nav>
<div class="bottom"><div class="menu-title">System</div><nav class="nav">
<button onclick="showNotifications()">${icons.notification}<span>Thông báo ${unread?`(${unread})`:""}</span></button>
<button onclick="go('settings')">${icons.settings}<span>Cài đặt</span></button>
<button onclick="login()">${icons.logout}<span>Đăng xuất</span></button>
</nav></div>
</aside>
<main class="main"><header class="topbar">
<input class="search" placeholder="Tìm kiếm..." onkeydown="if(event.key==='Enter') globalSearch(this.value)">
<div class="user"><div class="avatar">${DB.currentUser.initials}</div><div><b>${esc(DB.currentUser.name)}</b><div class="muted">${roleLabel(role)}</div></div></div>
</header><section class="content">${content}</section></main><div id="overlay"></div>
</div>`;
}
function roleMenus(role){
const c=[["dashboard",icons.dashboard,"Dashboard"]];
return {
Employee:[...c,["profile",icons.employees,"Hồ sơ cá nhân"],["attendance",icons.attendance,"Chấm công"],["leave",icons.leave,"Nghỉ phép"],["overtime",icons.overtime,"Tăng ca"],["payslip",icons.payslip,"Phiếu lương"]],
Manager:[...c,["employees",icons.employees,"Nhân viên"],["attendance",icons.attendance,"Chấm công team"],["leave",icons.leave,"Duyệt nghỉ phép"],["overtime",icons.overtime,"Duyệt tăng ca"],["approvals",icons.reports,"Lịch sử phê duyệt"]],
HR:[...c,["employees",icons.employees,"Nhân viên"],["contracts",icons.contract,"Hợp đồng"],["onboarding",icons.onboarding,"Onboarding"],["attendance",icons.attendance,"Chấm công"],["leave",icons.leave,"Quản lý PTO"],["overtime",icons.overtime,"OT Schedule"],["payroll",icons.payroll,"Payroll"],["payslip",icons.payslip,"Payslip"],["reports",icons.reports,"Báo cáo"]],
Admin:[...c,["users",icons.users,"User Management"],["roles",icons.roles,"Role & Permission"],["otConfig",icons.overtime,"OT Configuration"],["taxConfig",icons.settings,"Tax Configuration"],["insuranceConfig",icons.settings,"Insurance Configuration"],["audit",icons.audit,"Audit Log"]]
}[role]||c;
}
function pageHead(title,sub,action=""){return `<div class="page-head"><div><h1>${title}</h1><p class="muted">${sub||""}</p></div>${action}</div>`;}
function stats(items){return `<div class="stats">${items.map(x=>`<div class="stat"><div class="stat-icon">${x[0]}</div><div><span>${x[1]}</span><b>${x[2]}</b></div></div>`).join("")}</div>`;}
function table(headers,rows){return `<div class="card"><div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows||`<tr><td colspan="${headers.length}" class="empty">Không có dữ liệu</td></tr>`}</tbody></table></div></div>`;}
function login(){
app.innerHTML=`<div class="login-page"><div class="login-box"><div class="login-brand"><div class="mark">H</div><div><b>HRM & Payroll</b><div class="muted">Employee Management Portal</div></div></div>
<h1>Đăng nhập hệ thống</h1><p class="muted">Demo final — 4 role dùng chung một mock data.</p>
<form onsubmit="event.preventDefault();handleLogin()"><div class="form-group"><label>Email</label><input id="loginEmail" class="input" type="email" value="hr@company.com" required></div>
<div class="form-group"><label>Mật khẩu</label><input id="loginPassword" class="input" type="password" value="123456" required></div>
<div class="form-group"><label>Vai trò demo</label><select id="loginRole" class="select"><option value="Employee">Employee — Nhân viên</option><option value="Manager">Manager — Quản lý</option><option value="HR" selected>HR</option><option value="Admin">Admin — Quản trị viên</option></select></div>
<button class="btn btn-primary" type="submit">Đăng nhập</button></form>
<div class="demo-accounts"><b>Tài khoản demo</b><div>Employee: employee@company.com / 123456</div><div>Manager: manager@company.com / 123456</div><div>HR: hr@company.com / 123456</div><div>Admin: admin@company.com / 123456</div></div>
<div class="login-note">Demo UI • Mock data • Không cần API/Database</div></div></div>`;
}
function handleLogin(){
const email=document.getElementById("loginEmail").value.trim().toLowerCase(), pass=document.getElementById("loginPassword").value, role=document.getElementById("loginRole").value;
const u=DB.users.find(x=>x.email===email&&x.password===pass&&x.role===role);
if(!u)return toast("Thông tin đăng nhập hoặc role không đúng");
DB.currentUser={id:u.id,name:u.name,email:u.email,role:u.role,initials:u.initials};
addAudit("Login","AUTH"); go("dashboard");
}
function globalSearch(q){if(!q.trim())return;const hit=DB.employees.find(e=>Object.values(e).some(v=>String(v).toLowerCase().includes(q.toLowerCase())));toast(hit?`Tìm thấy: ${hit.name}`:`Không tìm thấy "${q}"`);}
function dashboard(){
const r=DB.currentUser.role;
if(r==="Employee")return employeeDashboard();
if(r==="Manager")return managerDashboard();
if(r==="HR")return hrDashboard();
return adminDashboard();
}
function employeeDashboard(){
const me=currentEmployee(), myPto=DB.leaveRequests.filter(x=>x.employeeId===me.id), myOt=DB.otRegistrations.filter(x=>x.employeeId===me.id);
const pays=DB.payroll.find(x=>x.employeeId===me.id);
app.innerHTML=shell(`${pageHead("Dashboard Nhân viên","Tổng quan hồ sơ, PTO, OT và lương")}
${stats([["👤","Trạng thái",me.status],["🌴","Phép còn",me.leaveBalance+" ngày"],["⏱","OT đăng ký",myOt.length],["₫","Net payroll",pays?.net||"—"]])}
<div class="grid2"><div class="card"><div class="card-head"><h3>Trạng thái PTO</h3><button class="btn btn-light btn-small" onclick="go('leave')">Quản lý</button></div>${myPto.map(x=>`<div class="request-row"><div><b>${x.type}</b><span>${x.from} - ${x.to} • ${x.days} ngày</span></div>${badge(x.status)}</div>`).join("")||'<div class="empty">Chưa có đơn.</div>'}</div>
<div class="card"><div class="card-head"><h3>Lịch OT đã công bố</h3><button class="btn btn-light btn-small" onclick="go('overtime')">Xem</button></div>${DB.otSchedules.filter(x=>x.department===me.department||x.department==="Engineering").slice(0,3).map(x=>`<div class="schedule-row"><div><b>${x.id} • ${x.date}</b><span class="muted">${x.time} • ${x.department}</span></div>${badge(x.status)}</div>`).join("")}</div></div>`,"dashboard");
}
function managerDashboard(){
const pl=DB.managerApprovals.filter(x=>x.status==="Pending").length, po=DB.otRegistrations.filter(x=>x.status==="Pending").length;
app.innerHTML=shell(`${pageHead("Dashboard Quản lý","Tổng quan team và các yêu cầu cần phê duyệt")}
${stats([["👥","Nhân viên team",DB.team.length],["✓","Có mặt",DB.team.filter(x=>x.attendance==="Present").length+"/"+DB.team.length],["📄","PTO chờ duyệt",pl],["⏱","OT chờ duyệt",po]])}
<div class="grid2"><div class="card"><div class="card-head"><h3>Yêu cầu nghỉ phép</h3><button class="btn btn-light btn-small" onclick="go('leave')">Xem tất cả</button></div>
${DB.managerApprovals.filter(x=>x.status==="Pending").map(x=>`<div class="request-row"><div><b>${x.employee}</b><span>${x.type} • ${x.days} ngày</span></div><button class="btn btn-primary btn-small" onclick="go('leave')">Duyệt</button></div>`).join("")||'<div class="empty">Không có yêu cầu.</div>'}</div>
<div class="card"><div class="card-head"><h3>Đăng ký OT</h3><button class="btn btn-light btn-small" onclick="go('overtime')">Xem tất cả</button></div>
${DB.otRegistrations.filter(x=>x.status==="Pending").map(x=>`<div class="request-row"><div><b>${x.employee}</b><span>${x.schedule} • ${x.hours} giờ</span></div><button class="btn btn-primary btn-small" onclick="go('overtime')">Duyệt</button></div>`).join("")||'<div class="empty">Không có đăng ký.</div>'}</div></div>`,"dashboard");
}
function hrDashboard(){
const active=DB.employees.filter(x=>x.status==="Active").length, pending=DB.leaveRequests.filter(x=>x.status==="Pending").length;
app.innerHTML=shell(`${pageHead("Dashboard HR","Quản lý nhân sự, PTO, OT và Payroll")}
${stats([["👥","Nhân viên active",active],["📄","PTO pending",pending],["⏱","OT schedules",DB.otSchedules.length],["₫","Payroll records",DB.payroll.length]])}
<div class="grid2"><div class="card"><div class="card-head"><h3>Luồng liên thông</h3></div><div class="alert">Manager duyệt PTO/OT → HR thấy Approved → Payroll/Payslip dùng cùng DB.</div><div class="stat-list"><div class="stat-row"><span>PTO Approved</span><b>${DB.leaveRequests.filter(x=>x.status==="Approved").length}</b></div><div class="stat-row"><span>OT Approved</span><b>${DB.otRegistrations.filter(x=>x.status==="Approved").length}</b></div><div class="stat-row"><span>Onboarding In Progress</span><b>${DB.onboarding.filter(x=>x.status==="In Progress").length}</b></div></div></div>
<div class="card"><div class="card-head"><h3>Notification HR</h3></div>${DB.notifications.filter(x=>x.to==="HR").slice(0,4).map(n=>`<div class="request-row"><div><b>${n.title}</b><span>${n.message}</span></div>${n.read?"":"●"}</div>`).join("")}</div></div>`,"dashboard");
}
function adminDashboard(){
app.innerHTML=shell(`${pageHead("Admin Dashboard","Quản trị tài khoản, quyền và cấu hình hệ thống")}
${stats([["👥","Users",DB.users.length],["🔐","Roles",DB.roles.length],["⏱","OT config",DB.otConfig.maxHours+"h"],["▥","Audit logs",DB.auditLogs.length]])}
<div class="grid2"><div class="card"><div class="card-head"><h3>System health</h3></div><div class="stat-list"><div class="stat-row"><span>Mock data</span>${badge("Active")}</div><div class="stat-row"><span>Role access</span>${badge("Active")}</div><div class="stat-row"><span>Notification</span>${badge("Open")}</div></div></div>
<div class="card"><div class="card-head"><h3>Recent audit</h3></div>${DB.auditLogs.slice(0,4).map(x=>`<div class="request-row"><div><b>${x.action}</b><span>${x.user} • ${x.time}</span></div>${badge(x.result)}</div>`).join("")}</div></div>`,"dashboard");
}
function employeeProfile(){
const e=currentEmployee(); app.innerHTML=shell(`${pageHead("Hồ sơ cá nhân","Thông tin Employee")}
<div class="profile-grid"><div class="card profile-card"><div class="profile-avatar">${DB.currentUser.initials}</div><h2>${e.name}</h2><div class="profile-status">${badge(e.status)}</div><div class="profile-line"><span>Chức danh</span><b>${e.position}</b></div><div class="profile-line"><span>Phòng ban</span><b>${e.department}</b></div><div class="profile-line"><span>Ngày vào làm</span><b>${e.joinDate}</b></div></div>
<div class="card"><div class="panel-head"><h3>Employee Detail</h3></div><div class="detail-grid"><div><span>Email</span><b>${e.email}</b></div><div><span>Điện thoại</span><b>${e.phone}</b></div><div><span>Quản lý</span><b>${e.manager}</b></div><div><span>Lương cơ bản</span><b>${e.salary}</b></div><div><span>Phép còn</span><b>${e.leaveBalance} ngày</b></div><div><span>Employee ID</span><b>${e.id}</b></div></div></div></div>`,"profile");
}
function employeeAttendance(){
const e=currentEmployee(), rows=DB.attendance.filter(x=>x.employee===e.name);
app.innerHTML=shell(`${pageHead("Chấm công","Lịch sử chấm công của bạn")}
${stats([["✓","Ngày có mặt",rows.filter(x=>x.status==="Present").length],["!","Đi trễ",rows.filter(x=>x.status==="Late").length],["⏱","Tổng bản ghi",rows.length]])}
${table(["Ngày","Check-in","Check-out","Tổng giờ","Trạng thái"],rows.map(x=>`<tr><td>${x.date}</td><td>${x.checkin}</td><td>${x.checkout}</td><td>${x.hours}</td><td>${badge(x.status)}</td></tr>`).join(""))}`,"attendance");
}
function employeeLeave(){
const e=currentEmployee(), rows=DB.leaveRequests.filter(x=>x.employeeId===e.id);
app.innerHTML=shell(`${pageHead("Nghỉ phép","Quản lý PTO",`<button class="btn btn-primary" onclick="showPtoForm()">+ Tạo đơn PTO</button>`)}
${stats([["🌴","Phép còn",e.leaveBalance+" ngày"],["📄","Tổng đơn",rows.length],["⏳","Pending",rows.filter(x=>x.status==="Pending").length]])}
${table(["Mã","Loại","Từ ngày","Đến ngày","Ngày","Lý do","Trạng thái"],rows.map(x=>`<tr><td>${x.id}</td><td>${x.type}</td><td>${x.from}</td><td>${x.to}</td><td>${x.days}</td><td>${x.reason}</td><td>${badge(x.status)}</td></tr>`).join(""))}`,"leave");
}
function showPtoForm(){
showModal("Tạo đơn nghỉ phép",`<form onsubmit="event.preventDefault();createPto()"><div class="form-grid"><div class="form-group"><label>Loại</label><select id="ptoType" class="select"><option>Annual Leave</option><option>Sick Leave</option><option>Personal Leave</option></select></div><div class="form-group"><label>Số ngày</label><input id="ptoDays" class="input" type="number" min="1" value="1"></div><div class="form-group"><label>Từ ngày</label><input id="ptoFrom" class="input" type="date" value=""></div><div class="form-group"><label>Đến ngày</label><input id="ptoTo" class="input" type="date" value=""></div><div class="form-group full"><label>Lý do</label><input id="ptoReason" class="input" required placeholder="Nhập lý do"></div></div><div class="form-actions"><button type="button" class="btn btn-light" onclick="closeModal()">Hủy</button><button class="btn btn-primary">Gửi đơn</button></div></form>`);
}
function createPto(){
const e=currentEmployee(), item={id:"PTO"+String(Date.now()).slice(-6),employee:e.name,employeeId:e.id,type:document.getElementById("ptoType").value,from:document.getElementById("ptoFrom").value,to:document.getElementById("ptoTo").value,days:Number(document.getElementById("ptoDays").value),status:"Pending",reason:document.getElementById("ptoReason").value};
DB.leaveRequests.unshift(item);DB.managerApprovals.unshift({...item});addNotification("Manager","PTO mới",`${e.name} vừa tạo đơn PTO, đang chờ duyệt.`);addAudit("Created PTO",item.id);closeModal();toast("Đã gửi đơn PTO");employeeLeave();
}
function employeeOvertime(){
const e=currentEmployee(), regs=DB.otRegistrations.filter(x=>x.employeeId===e.id);
app.innerHTML=shell(`${pageHead("Tăng ca","Lịch OT do HR công bố và đăng ký của bạn")}
<div class="card"><div class="card-head"><h3>Lịch OT</h3></div><div class="table-wrap"><table><thead><tr><th>Mã</th><th>Ngày</th><th>Thời gian</th><th>Phòng ban</th><th>Slot</th><th>Trạng thái</th><th></th></tr></thead><tbody>
${DB.otSchedules.map(x=>`<tr><td>${x.id}</td><td>${x.date}</td><td>${x.time}</td><td>${x.department}</td><td>${x.slots}</td><td>${badge(x.status)}</td><td>${x.status==="Open"?`<button class="btn btn-primary btn-small" onclick="showOtRegister('${x.id}')">Đăng ký</button>`:""}</td></tr>`).join("")}</tbody></table></div></div>
<div class="card"><div class="panel-head"><h3>Đăng ký của tôi</h3></div>${regs.length?`<div class="table-wrap"><table><thead><tr><th>Mã</th><th>Lịch</th><th>Ngày</th><th>Giờ</th><th>Lý do</th><th>Status</th></tr></thead><tbody>${regs.map(x=>`<tr><td>${x.id}</td><td>${x.schedule}</td><td>${x.date}</td><td>${x.hours}h</td><td>${x.reason}</td><td>${badge(x.status)}</td></tr>`).join("")}</tbody></table></div>`:'<div class="empty">Chưa đăng ký OT.</div>'}</div>`,"overtime");
}
function showOtRegister(id){
const s=DB.otSchedules.find(x=>x.id===id); if(!s)return;
showModal("Đăng ký OT",`<form onsubmit="event.preventDefault();registerOt('${id}')"><div class="alert">${s.id} • ${s.date} • ${s.time} • ${s.department}</div><div class="form-group"><label>Số giờ</label><input id="otHours" class="input" type="number" min="1" max="8" value="0"></div><div class="form-group"><label>Lý do</label><input id="otReason" class="input" required placeholder="Lý do tăng ca"></div><div class="form-actions"><button type="button" class="btn btn-light" onclick="closeModal()">Hủy</button><button class="btn btn-primary">Gửi đăng ký</button></div></form>`);
}
function registerOt(id){
const s=DB.otSchedules.find(x=>x.id===id),e=currentEmployee(), hours=Number(document.getElementById("otHours").value);
const item={id:"OTR"+String(Date.now()).slice(-6),employee:e.name,employeeId:e.id,schedule:s.id,date:s.date,time:s.time,hours,status:"Pending",reason:document.getElementById("otReason").value};
DB.otRegistrations.unshift(item);addNotification("Manager","Đăng ký OT mới",`${e.name} đăng ký ${s.id}, đang chờ duyệt.`);addAudit("Registered OT",item.id);closeModal();toast("Đã gửi đăng ký OT");employeeOvertime();
}
function employeePayslip(){
const e=currentEmployee(), p=DB.payroll.find(x=>x.employeeId===e.id);
app.innerHTML=shell(`${pageHead("Phiếu lương","Payslip tháng "+(p?.period||"09/2026"),p?`<button class="btn btn-light" onclick="window.print()">In Payslip</button>`:"")}
${p?`<div class="card payslip"><div class="payslip-title"><h2>HRM & Payroll</h2><p class="muted">PAYSLIP • ${p.period}</p></div><div class="detail-grid"><div><span>Nhân viên</span><b>${p.name}</b></div><div><span>Mã NV</span><b>${p.employeeId}</b></div><div><span>Gross</span><b>${p.gross}</b></div><div><span>OT</span><b>${p.ot}</b></div><div><span>Insurance</span><b>${p.insurance}</b></div><div><span>Tax</span><b>${p.tax}</b></div></div><div class="payslip-total">Net: ${p.net}</div><div class="form-actions">${badge(p.status)}</div></div>`:'<div class="empty">Chưa có payslip.</div>'}`,"payslip");
}
function managerEmployees(){
app.innerHTML=shell(`${pageHead("Nhân viên","Danh sách team")}
${table(["Mã NV","Nhân viên","Phòng ban","Chức danh","Chấm công","Phép còn","Trạng thái"],DB.team.map(e=>`<tr><td>${e.id}</td><td><b>${e.name}</b></td><td>${e.department}</td><td>${e.position}</td><td>${badge(e.attendance)}</td><td>${e.leaveBalance} ngày</td><td>${badge(e.status)}</td></tr>`).join(""))}`,"employees");
}
function managerAttendance(){
const rows=DB.attendance.filter(x=>DB.team.some(e=>e.name===x.employee));
app.innerHTML=shell(`${pageHead("Chấm công team","Theo dõi attendance")}
${stats([["✓","Có mặt",DB.team.filter(x=>x.attendance==="Present").length],["!","Đi trễ",DB.team.filter(x=>x.attendance==="Late").length],["×","Vắng",DB.team.filter(x=>x.attendance==="Absent").length]])}
${table(["Ngày","Nhân viên","Check-in","Check-out","Tổng giờ","Trạng thái"],rows.map(x=>`<tr><td>${x.date}</td><td><b>${x.employee}</b></td><td>${x.checkin}</td><td>${x.checkout}</td><td>${x.hours}</td><td>${badge(x.status)}</td></tr>`).join(""))}`,"attendance");
}
function managerLeave(){
app.innerHTML=shell(`${pageHead("Duyệt nghỉ phép","Manager phê duyệt PTO của team")}
${table(["Nhân viên","Loại","Thời gian","Ngày","Lý do","Trạng thái","Thao tác"],DB.managerApprovals.map(x=>`<tr><td><b>${x.employee}</b></td><td>${x.type}</td><td>${x.from} - ${x.to}</td><td>${x.days}</td><td>${x.reason}</td><td>${badge(x.status)}</td><td>${x.status==="Pending"?`<button class="btn btn-primary btn-small" onclick="managerDecision('leave','${x.id}','Approved')">Duyệt</button> <button class="btn btn-danger btn-small" onclick="managerDecision('leave','${x.id}','Rejected')">Từ chối</button>`:"Đã xử lý"}</td></tr>`).join(""))}`,"leave");
}
function managerOvertime(){
app.innerHTML=shell(`${pageHead("Duyệt tăng ca","Manager duyệt đăng ký OT")}
<div class="card"><div class="panel-head"><h3>Lịch OT của team</h3></div>${table(["Mã lịch","Ngày","Thời gian","Phòng ban","Slot","Trạng thái"],DB.otSchedules.filter(x=>x.department==="Engineering").map(x=>`<tr><td>${x.id}</td><td>${x.date}</td><td>${x.time}</td><td>${x.department}</td><td>${x.slots}</td><td>${badge(x.status)}</td></tr>`).join(""))}</div>
<div class="card"><div class="panel-head"><h3>Đăng ký OT</h3></div>${table(["Nhân viên","Lịch","Ngày","Giờ","Lý do","Trạng thái","Thao tác"],DB.otRegistrations.map(x=>`<tr><td>${x.employee}</td><td>${x.schedule}</td><td>${x.date}</td><td>${x.hours}h</td><td>${x.reason}</td><td>${badge(x.status)}</td><td>${x.status==="Pending"?`<button class="btn btn-primary btn-small" onclick="managerDecision('ot','${x.id}','Approved')">Duyệt</button> <button class="btn btn-danger btn-small" onclick="managerDecision('ot','${x.id}','Rejected')">Từ chối</button>`:"Đã xử lý"}</td></tr>`).join(""))}</div>`,"overtime");
}
function managerApprovals(){
app.innerHTML=shell(`${pageHead("Lịch sử phê duyệt","PTO và OT")}
${table(["Mã","Nhân viên","Loại","Yêu cầu","Ngày","Quyết định","Ngày xử lý"],DB.approvalHistory.map(x=>`<tr><td>${x.id}</td><td>${x.employee}</td><td>${x.type}</td><td>${x.request}</td><td>${x.date}</td><td>${badge(x.decision)}</td><td>${x.processed}</td></tr>`).join(""))}`,"approvals");
}
function managerDecision(type,id,decision){
if(type==="leave"){
const item=DB.managerApprovals.find(x=>x.id===id);if(!item)return;
item.status=decision;
const original=DB.leaveRequests.find(x=>x.id===id);if(original)original.status=decision;
DB.approvalHistory.unshift({id:"APR"+String(Date.now()).slice(-5),employee:item.employee,type:"PTO",request:item.type,date:item.from,decision,processed:"19/09/2026"});
addNotification("HR","PTO đã được xử lý",`${item.employee}: ${item.type} → ${decision}.`);
}else{
const item=DB.otRegistrations.find(x=>x.id===id);if(!item)return;
item.status=decision;
DB.approvalHistory.unshift({id:"APR"+String(Date.now()).slice(-5),employee:item.employee,type:"OT",request:item.schedule,date:item.date,decision,processed:"19/09/2026"});
addNotification("HR","OT đã được xử lý",`${item.employee}: ${item.schedule} → ${decision}.`);
}
addAudit(`Manager ${decision}`,id);toast(decision==="Approved"?"Đã duyệt":"Đã từ chối");type==="leave"?managerLeave():managerOvertime();
}
function hrEmployees(){
app.innerHTML=shell(`${pageHead("Nhân viên","Employee master data",`<button class="btn btn-primary" onclick="showEmployeeForm()">+ Thêm nhân viên</button>`)}
${table(["Mã NV","Họ tên","Phòng ban","Chức danh","Email","Lương","Trạng thái","Thao tác"],DB.employees.map(e=>`<tr><td>${e.id}</td><td><b>${e.name}</b></td><td>${e.department}</td><td>${e.position}</td><td>${e.email}</td><td>${e.salary}</td><td>${badge(e.status)}</td><td><button class="btn btn-light btn-small" onclick="showEmployeeDetail('${e.id}')">Chi tiết</button> <button class="btn btn-danger btn-small" onclick="deleteEmployee('${e.id}')">Xóa</button></td></tr>`).join(""))}`,"employees");
}

function showEmployeeDetail(id){
const e=DB.employees.find(x=>x.id===id);if(!e)return;
showModal("Chỉnh sửa nhân viên",`<form onsubmit="event.preventDefault();updateEmployee('${id}')"><div class="form-grid">
<div class="form-group"><label>Họ và tên</label><input id="editName" class="input" value="${e.name}" required></div>
<div class="form-group"><label>Email</label><input id="editEmail" class="input" type="email" value="${e.email}" required></div>
<div class="form-group"><label>Số điện thoại</label><input id="editPhone" class="input" value="${e.phone||""}" required></div>
<div class="form-group"><label>Phòng ban</label><select id="editDepartment" class="select"><option value=""> </option><option ${e.department==="Engineering"?"selected":""}>Engineering</option><option ${e.department==="Marketing"?"selected":""}>Marketing</option><option ${e.department==="Human Resources"?"selected":""}>Human Resources</option><option ${e.department==="Finance"?"selected":""}>Finance</option></select></div>
<div class="form-group"><label>Chức danh</label><input id="editPosition" class="input" value="${e.position}" required></div>
<div class="form-group"><label>Quản lý trực tiếp</label><select id="editManager" class="select"><option value=""> </option><option ${e.manager==="Trần Minh Khoa"?"selected":""}>Trần Minh Khoa</option><option ${e.manager==="Nguyễn Minh Anh"?"selected":""}>Nguyễn Minh Anh</option><option ${e.manager==="Không có"?"selected":""}>Không có</option></select></div>
<div class="form-group"><label>Ngày vào làm</label><input id="editJoinDate" class="input" value="${e.joinDate||""}"></div>
<div class="form-group"><label>Lương cơ bản</label><input id="editSalary" class="input" value="${e.salary}" required></div>
<div class="form-group"><label>Số ngày phép</label><input id="editLeave" class="input" type="number" min="0" value="${e.leaveBalance||0}"></div>
<div class="form-group"><label>Trạng thái</label><select id="editStatus" class="select"><option ${e.status==="Active"?"selected":""}>Active</option><option ${e.status==="Inactive"?"selected":""}>Inactive</option></select></div>
</div><div class="form-actions"><button type="button" class="btn btn-light" onclick="closeModal()">Hủy</button><button class="btn btn-primary">Lưu thay đổi</button></div></form>`);
}
function showEmployeeForm(){
showModal("Thêm nhân viên",`<form onsubmit="event.preventDefault();createEmployee()"><div class="form-grid">
<div class="form-group"><label>Họ và tên</label><input id="empName" class="input" required placeholder=""></div>
<div class="form-group"><label>Email</label><input id="empEmail" class="input" type="email" required placeholder=""></div>
<div class="form-group"><label>Số điện thoại</label><input id="empPhone" class="input" required placeholder=""></div>
<div class="form-group"><label>Phòng ban</label><select id="empDepartment" class="select"><option>Engineering</option><option>Marketing</option><option>Human Resources</option><option>Finance</option></select></div>
<div class="form-group"><label>Chức danh</label><input id="empPosition" class="input" required placeholder=""></div>
<div class="form-group"><label>Quản lý trực tiếp</label><select id="empManager" class="select"><option>Trần Minh Khoa</option><option>Nguyễn Minh Anh</option><option>Không có</option></select></div>
<div class="form-group"><label>Ngày vào làm</label><input id="empJoinDate" class="input" type="date" value=""></div>
<div class="form-group"><label>Lương cơ bản</label><input id="empSalary" class="input" required placeholder=""></div>
<div class="form-group"><label>Số ngày phép</label><input id="empLeave" class="input" type="number" min="0" value="0"></div>
<div class="form-group"><label>Trạng thái</label><select id="empStatus" class="select"><option>Active</option><option>Inactive</option></select></div>
</div><div class="form-actions"><button type="button" class="btn btn-light" onclick="closeModal()">Hủy</button><button class="btn btn-primary">Lưu nhân viên</button></div></form>`);
}

function createEmployee(){
const name=document.getElementById("empName").value.trim(),email=document.getElementById("empEmail").value.trim(),phone=document.getElementById("empPhone").value.trim(),department=document.getElementById("empDepartment").value,position=document.getElementById("empPosition").value.trim(),manager=document.getElementById("empManager").value,joinDate=document.getElementById("empJoinDate").value,salary=document.getElementById("empSalary").value.trim(),leaveBalance=Number(document.getElementById("empLeave").value),status=document.getElementById("empStatus").value;
if(DB.employees.some(e=>e.email.toLowerCase()===email.toLowerCase()))return toast("Email nhân viên đã tồn tại");
const id="EMP"+String(DB.employees.length+1).padStart(3,"0"),initials=name.split(" ").filter(Boolean).map(x=>x[0]).slice(-2).join("").toUpperCase();
const employee={id,name,email,phone,department,position,manager,joinDate,salary,leaveBalance,status,initials,attendance:"Present"};
DB.employees.push(employee);
DB.ptoBalances.push({employeeId:id,employee:name,annual:leaveBalance,used:0,remaining:leaveBalance});
addAudit("Created Employee",id);addNotification("HR","Nhân viên mới",`${name} đã được thêm vào hệ thống.`);
closeModal();toast(`Đã thêm nhân viên ${name}`);hrEmployees();
}
function updateEmployee(id){
const e=DB.employees.find(x=>x.id===id);if(!e)return;
const email=document.getElementById("editEmail").value.trim();
if(DB.employees.some(x=>x.id!==id&&x.email.toLowerCase()===email.toLowerCase()))return toast("Email nhân viên đã tồn tại");
e.name=document.getElementById("editName").value.trim();
e.email=email;
e.phone=document.getElementById("editPhone").value.trim();
e.department=document.getElementById("editDepartment").value;
e.position=document.getElementById("editPosition").value.trim();
e.manager=document.getElementById("editManager").value;
e.joinDate=document.getElementById("editJoinDate").value;
e.salary=document.getElementById("editSalary").value.trim();
e.leaveBalance=Number(document.getElementById("editLeave").value);
e.status=document.getElementById("editStatus").value;
e.initials=e.name.split(" ").filter(Boolean).map(x=>x[0]).slice(-2).join("").toUpperCase();
const p=DB.ptoBalances.find(x=>x.employeeId===id);
if(p){p.employee=e.name;p.annual=e.leaveBalance;p.remaining=e.leaveBalance-p.used;}
addAudit("Updated Employee",id);addNotification("HR","Cập nhật nhân viên",`${e.name} đã được cập nhật thông tin.`);
closeModal();toast(`Đã cập nhật ${e.name}`);hrEmployees();
}
function deleteEmployee(id){
const e=DB.employees.find(x=>x.id===id);if(!e)return;
if(!confirm(`Bạn có chắc muốn xóa nhân viên "${e.name}" không?`))return;
DB.employees=DB.employees.filter(x=>x.id!==id);
DB.ptoBalances=DB.ptoBalances.filter(x=>x.employeeId!==id);
DB.attendance=DB.attendance.filter(x=>x.employeeId!==id&&x.employee!==e.name);
DB.contracts=DB.contracts.filter(x=>x.employeeId!==id);
DB.onboarding=DB.onboarding.filter(x=>x.employeeId!==id);
addAudit("Deleted Employee",id);addNotification("HR","Xóa nhân viên",`${e.name} đã được xóa khỏi hệ thống.`);
toast(`Đã xóa nhân viên ${e.name}`);hrEmployees();
}
function hrContracts(){
app.innerHTML=shell(`${pageHead("Hợp đồng","Quản lý hợp đồng lao động",`<button class="btn btn-primary" onclick="showContractForm()">+ Thêm hợp đồng</button>`)}
${table(["Mã","Nhân viên","Loại","Bắt đầu","Kết thúc","Lương","Trạng thái"],DB.contracts.map(x=>`<tr><td>${x.id}</td><td>${x.employee}</td><td>${x.type}</td><td>${x.start}</td><td>${x.end}</td><td>${x.salary}</td><td>${badge(x.status)}</td></tr>`).join(""))}`,"contracts");
}
function showContractForm(){
showModal("Thêm hợp đồng",`<form onsubmit="event.preventDefault();createContract()"><div class="form-grid"><div class="form-group"><label>Nhân viên</label><select id="ctrEmployee" class="select">${DB.employees.filter(e=>e.status==="Active").map(e=>`<option value="${e.id}">${e.name}</option>`).join("")}</select></div><div class="form-group"><label>Loại</label><select id="ctrType" class="select"><option>Indefinite</option><option>Fixed-term</option></select></div><div class="form-group"><label>Bắt đầu</label><input id="ctrStart" class="input" type="date" value=""></div><div class="form-group"><label>Kết thúc</label><input id="ctrEnd" class="input" value="Không thời hạn"></div><div class="form-group"><label>Lương</label><input id="ctrSalary" class="input" value=""></div></div><div class="form-actions"><button type="button" class="btn btn-light" onclick="closeModal()">Hủy</button><button class="btn btn-primary">Lưu</button></div></form>`);
}
function createContract(){
const e=DB.employees.find(x=>x.id===document.getElementById("ctrEmployee").value);
DB.contracts.push({id:"CTR"+String(Date.now()).slice(-5),employeeId:e.id,employee:e.name,type:document.getElementById("ctrType").value,start:document.getElementById("ctrStart").value,end:document.getElementById("ctrEnd").value,status:"Active",salary:document.getElementById("ctrSalary").value});
addAudit("Created Contract",e.id);closeModal();toast("Đã tạo hợp đồng");hrContracts();
}
function hrOnboarding(){
app.innerHTML=shell(`${pageHead("Onboarding","Theo dõi checklist nhân viên mới",`<button class="btn btn-primary" onclick="showOnboardingForm()">+ Tạo onboarding</button>`)}
${table(["Mã","Nhân viên","Ngày bắt đầu","Tiến độ","Checklist","Trạng thái"],DB.onboarding.map(x=>`<tr><td>${x.id}</td><td>${x.employee}</td><td>${x.start}</td><td><div class="progress"><span style="width:${x.progress}%"></span></div>${x.progress}%</td><td>${x.items}</td><td>${badge(x.status)}</td></tr>`).join(""))}`,"onboarding");
}
function showOnboardingForm(){showModal("Tạo onboarding",`<form onsubmit="event.preventDefault();createOnboarding()"><div class="form-grid"><div class="form-group full"><label>Nhân viên</label><select id="onbEmployee" class="select">${DB.employees.filter(e=>e.status==="Active").map(e=>`<option value="${e.id}">${e.name}</option>`).join("")}</select></div><div class="form-group"><label>Ngày bắt đầu</label><input id="onbStart" class="input" type="date" value=""></div><div class="form-group"><label>Tiến độ %</label><input id="onbProgress" class="input" type="number" value="0" min="0" max="100"></div></div><div class="form-actions"><button type="button" class="btn btn-light" onclick="closeModal()">Hủy</button><button class="btn btn-primary">Lưu</button></div></form>`);}
function createOnboarding(){const e=DB.employees.find(x=>x.id===document.getElementById("onbEmployee").value),p=Number(document.getElementById("onbProgress").value);DB.onboarding.push({id:"ONB"+String(Date.now()).slice(-5),employee:e.name,employeeId:e.id,start:document.getElementById("onbStart").value,progress:p,status:p>=100?"Completed":"In Progress",items:"Tài khoản"});addAudit("Created Onboarding",e.id);closeModal();toast("Đã tạo onboarding");hrOnboarding();}
function hrAttendance(){app.innerHTML=shell(`${pageHead("Chấm công","Toàn bộ dữ liệu attendance")}${table(["Ngày","Nhân viên","Check-in","Check-out","Giờ","Trạng thái"],DB.attendance.map(x=>`<tr><td>${x.date}</td><td>${x.employee}</td><td>${x.checkin}</td><td>${x.checkout}</td><td>${x.hours}</td><td>${badge(x.status)}</td></tr>`).join(""))}`,"attendance");}
function hrLeave(){
app.innerHTML=shell(`${pageHead("Quản lý PTO","HR nhìn thấy trạng thái đã được Manager xử lý")}
${stats([["📄","Tổng đơn",DB.leaveRequests.length],["✓","Approved",DB.leaveRequests.filter(x=>x.status==="Approved").length],["⏳","Pending",DB.leaveRequests.filter(x=>x.status==="Pending").length],["×","Rejected",DB.leaveRequests.filter(x=>x.status==="Rejected").length]])}
${table(["Mã","Nhân viên","Loại","Thời gian","Ngày","Lý do","Trạng thái"],DB.leaveRequests.map(x=>`<tr><td>${x.id}</td><td>${x.employee}</td><td>${x.type}</td><td>${x.from} - ${x.to}</td><td>${x.days}</td><td>${x.reason}</td><td>${badge(x.status)}</td></tr>`).join(""))}`,"leave");
}
function hrOvertime(){
app.innerHTML=shell(`${pageHead("OT Schedule","HR tạo lịch OT — Employee nhìn thấy ngay",`<button class="btn btn-primary" onclick="showScheduleForm()">+ Tạo OT Schedule</button>`)}
${table(["Mã","Ngày","Thời gian","Phòng ban","Slot","Rate","Trạng thái"],DB.otSchedules.map(x=>`<tr><td>${x.id}</td><td>${x.date}</td><td>${x.time}</td><td>${x.department}</td><td>${x.slots}</td><td>${x.rate}</td><td>${badge(x.status)}</td></tr>`).join(""))}
<div class="card"><div class="panel-head"><h3>Employee OT registrations</h3></div>${table(["Nhân viên","Schedule","Ngày","Giờ","Trạng thái"],DB.otRegistrations.map(x=>`<tr><td>${x.employee}</td><td>${x.schedule}</td><td>${x.date}</td><td>${x.hours}h</td><td>${badge(x.status)}</td></tr>`).join(""))}</div>`,"overtime");
}
function showScheduleForm(){showModal("Tạo OT Schedule",`<form onsubmit="event.preventDefault();createSchedule()"><div class="form-grid"><div class="form-group"><label>Ngày</label><input id="schDate" class="input" type="date" value=""></div><div class="form-group"><label>Thời gian</label><input id="schTime" class="input" type="time" value=""></div><div class="form-group"><label>Phòng ban</label><select id="schDept" class="select"><option>Engineering</option><option>Marketing</option><option>Finance</option><option>Human Resources</option></select></div><div class="form-group"><label>Số slot</label><input id="schSlots" class="input" value="0/10"></div><div class="form-group"><label>OT Rate</label><select id="schRate" class="select"><option>150%</option><option>200%</option><option>300%</option></select></div></div><div class="form-actions"><button type="button" class="btn btn-light" onclick="closeModal()">Hủy</button><button class="btn btn-primary">Tạo lịch</button></div></form>`);}
function createSchedule(){const x={id:"OT"+String(Date.now()).slice(-5),date:document.getElementById("schDate").value,time:document.getElementById("schTime").value,department:document.getElementById("schDept").value,slots:document.getElementById("schSlots").value,status:"Open",rate:document.getElementById("schRate").value};DB.otSchedules.unshift(x);addNotification("Employee","Lịch OT mới",`HR đã tạo ${x.id} ngày ${x.date}.`);addNotification("Manager","Lịch OT mới",`HR đã tạo ${x.id} cho ${x.department}.`);addAudit("Created OT Schedule",x.id);closeModal();toast("Đã tạo OT Schedule");hrOvertime();}
function hrPayroll(){app.innerHTML=shell(`${pageHead("Payroll","Workflow: Draft → Calculated → Approved → Locked")}
${stats([["👥","Nhân viên",DB.payroll.length],["₫","Tổng Net",DB.payroll.reduce((s,x)=>s+Number(x.net.replaceAll(",","")),0).toLocaleString("vi-VN")+" ₫"],["⏱","OT payroll",DB.payroll.filter(x=>x.ot!=="0").length],["✓","Locked",DB.payroll.filter(x=>x.status==="Locked").length]])}
${table(["Mã","Nhân viên","Kỳ","Gross","OT","Insurance","Tax","Net","Status","Thao tác"],DB.payroll.map(x=>`<tr><td>${x.id}</td><td>${x.name}</td><td>${x.period}</td><td>${x.gross}</td><td>${x.ot}</td><td>${x.insurance}</td><td>${x.tax}</td><td><b>${x.net}</b></td><td>${badge(x.status)}</td><td>${x.status==="Draft"?`<button class="btn btn-light btn-small" onclick="payrollAction('${x.id}','Calculated')">Calculate</button>`:x.status==="Calculated"?`<button class="btn btn-primary btn-small" onclick="payrollAction('${x.id}','Approved')">Approve</button>`:x.status==="Approved"?`<button class="btn btn-primary btn-small" onclick="payrollAction('${x.id}','Locked')">Lock</button>`:"Đã khóa"}</td></tr>`).join(""))}
<div class="form-actions"><button class="btn btn-primary" onclick="generatePayroll()">Generate/Calculate Draft</button></div>`,"payroll");}
function generatePayroll(){const rows=DB.payroll.filter(x=>x.status==="Draft");rows.forEach(x=>x.status="Calculated");addAudit("Generated Payroll","PAYROLL");addNotification("HR","Payroll ready",`Đã chuyển ${rows.length} bảng lương Draft → Calculated.`);toast(rows.length?`Đã Calculate ${rows.length} bảng lương`:"Không có payroll Draft");hrPayroll();}
function payrollAction(id,next){const p=DB.payroll.find(x=>x.id===id);if(!p)return;const flow={Draft:"Calculated",Calculated:"Approved",Approved:"Locked"};if(flow[p.status]!==next)return toast("Không đúng trạng thái chuyển tiếp");p.status=next;addAudit(`Payroll ${next}`,id);addNotification("HR","Payroll cập nhật",`${id} đã chuyển sang ${next}.`);toast(`${id} → ${next}`);hrPayroll();}
function hrPayslip(){app.innerHTML=shell(`${pageHead("Payslip","Danh sách payslip đã tạo từ Payroll")}
${table(["Mã","Nhân viên","Kỳ","Net","Status","Thao tác"],DB.payroll.map(x=>`<tr><td>${x.id}</td><td>${x.name}</td><td>${x.period}</td><td><b>${x.net}</b></td><td>${badge(x.status)}</td><td><button class="btn btn-light btn-small" onclick="previewPayslip('${x.employeeId}')">Xem</button></td></tr>`).join(""))}`,"payslip");}
function previewPayslip(id){const p=DB.payroll.find(x=>x.employeeId===id);if(!p)return;showModal("Payslip",`<div class="payslip"><div class="payslip-title"><h2>HRM & Payroll</h2><p>${p.period}</p></div><div class="detail-grid"><div><span>Employee</span><b>${p.name}</b></div><div><span>Employee ID</span><b>${p.employeeId}</b></div><div><span>Gross</span><b>${p.gross}</b></div><div><span>OT</span><b>${p.ot}</b></div><div><span>Insurance</span><b>${p.insurance}</b></div><div><span>Tax</span><b>${p.tax}</b></div></div><div class="payslip-total">Net: ${p.net}</div></div>`);}
function hrReports(){app.innerHTML=shell(`${pageHead("Báo cáo HR","Tổng hợp HR")}
${stats([["👥","Active",DB.employees.filter(e=>e.status==="Active").length],["📄","PTO Approved",DB.leaveRequests.filter(x=>x.status==="Approved").length],["⏱","OT Approved",DB.otRegistrations.filter(x=>x.status==="Approved").length],["₫","Payslips",DB.payroll.length]])}<div class="grid2"><div class="card"><h3>Department</h3>${["Engineering","Marketing","Human Resources","Finance"].map(d=>`<div class="stat-row"><span>${d}</span><b>${DB.employees.filter(e=>e.department===d).length}</b></div>`).join("")}</div><div class="card"><h3>Approval status</h3><div class="stat-list"><div class="stat-row"><span>PTO Approved</span><b>${DB.leaveRequests.filter(x=>x.status==="Approved").length}</b></div><div class="stat-row"><span>OT Approved</span><b>${DB.otRegistrations.filter(x=>x.status==="Approved").length}</b></div></div></div></div>`,"reports");}
function adminUsers(){
app.innerHTML=shell(`${pageHead("User Management","Quản lý tài khoản hệ thống",`<button class="btn btn-primary" onclick="showUserForm()">+ Thêm user</button>`)}
${table(["ID","Tên","Email","Role","Status","Thao tác"],DB.users.map(u=>`<tr><td>${u.id}</td><td>${u.name}</td><td>${u.email}</td><td>${roleLabel(u.role)}</td><td>${badge(u.status)}</td><td><button class="btn btn-light btn-small" onclick="toggleUser('${u.id}')">${u.status==="Active"?"Disable":"Enable"}</button></td></tr>`).join(""))}`,"users");
}
function showUserForm(){showModal("Tạo user",`<form onsubmit="event.preventDefault();createUser()"><div class="form-grid"><div class="form-group"><label>Tên</label><input id="uName" class="input" required></div><div class="form-group"><label>Email</label><input id="uEmail" class="input" type="email" required></div><div class="form-group"><label>Password</label><input id="uPass" class="input" value="123456"></div><div class="form-group"><label>Role</label><select id="uRole" class="select"><option>Employee</option><option>Manager</option><option>HR</option><option>Admin</option></select></div></div><div class="form-actions"><button type="button" class="btn btn-light" onclick="closeModal()">Hủy</button><button class="btn btn-primary">Tạo</button></div></form>`);}
function createUser(){const name=document.getElementById("uName").value,email=document.getElementById("uEmail").value,role=document.getElementById("uRole").value;DB.users.push({id:"USR"+String(Date.now()).slice(-5),name,email,password:document.getElementById("uPass").value,role,initials:name.split(" ").map(x=>x[0]).slice(-2).join("").toUpperCase(),status:"Active"});addAudit("Created User",email);closeModal();toast("Đã tạo user");adminUsers();}
function toggleUser(id){const u=DB.users.find(x=>x.id===id);if(!u)return;u.status=u.status==="Active"?"Inactive":"Active";addAudit("Changed User Status",id);toast("Đã cập nhật user");adminUsers();}
function adminRoles(){app.innerHTML=shell(`${pageHead("Role & Permission","Ma trận quyền theo 4 role")}
${table(["Role","Mô tả","Dashboard","Profile","PTO","OT","Payroll","Admin"],DB.roles.map(r=>{const p=DB.permissions.find(x=>x.role===r.role)||{};return `<tr><td><b>${roleLabel(r.role)}</b></td><td>${r.description}</td><td>${p.dashboard?"✓":"—"}</td><td>${p.profile?"✓":"—"}</td><td>${p.leave?"✓":"—"}</td><td>${p.overtime?"✓":"—"}</td><td>${p.payroll?"✓":"—"}</td><td>${r.role==="Admin"?"✓":"—"}</td></tr>`}).join(""))}`,"roles");}
function configCard(title,fields,saveFn){return `<div class="card form-card"><div class="panel-head"><h3>${title}</h3></div><div class="form-grid">${fields.map(f=>`<div class="form-group"><label>${f[0]}</label><input id="${f[1]}" class="input" value="${f[2]}"></div>`).join("")}</div><div class="form-actions"><button class="btn btn-primary" onclick="${saveFn}()">Lưu cấu hình</button></div></div>`;}
function adminOtConfig(){app.innerHTML=shell(`${pageHead("OT Configuration","Cấu hình hệ số tăng ca và giới hạn")} ${configCard("OT Rules",[["Ngày thường","otWeek",DB.otConfig.weekdayRate],["Cuối tuần","otWeekend",DB.otConfig.weekendRate],["Ngày lễ","otHoliday",DB.otConfig.holidayRate],["Max hours / day","otMax",DB.otConfig.maxHours]],"saveOtConfig")}`,"otConfig");}
function saveOtConfig(){DB.otConfig={weekdayRate:document.getElementById("otWeek").value,weekendRate:document.getElementById("otWeekend").value,holidayRate:document.getElementById("otHoliday").value,maxHours:document.getElementById("otMax").value,approvalRequired:true};addAudit("Updated OT Configuration","OT_CONFIG");toast("Đã lưu OT Configuration");adminOtConfig();}
function adminTaxConfig(){app.innerHTML=shell(`${pageHead("Tax Configuration","Cấu hình thuế thu nhập cá nhân")} ${configCard("Tax Rules",[["Giảm trừ bản thân","taxPersonal",DB.taxConfig.personalDeduction],["Giảm trừ người phụ thuộc","taxDependent",DB.taxConfig.dependentDeduction],["Phương pháp","taxMethod",DB.taxConfig.method]],"saveTaxConfig")}`,"taxConfig");}
function saveTaxConfig(){DB.taxConfig={personalDeduction:document.getElementById("taxPersonal").value,dependentDeduction:document.getElementById("taxDependent").value,method:document.getElementById("taxMethod").value};addAudit("Updated Tax Configuration","TAX_CONFIG");toast("Đã lưu Tax Configuration");adminTaxConfig();}
function adminInsuranceConfig(){app.innerHTML=shell(`${pageHead("Insurance Configuration","Cấu hình BHXH/BHYT/BHTN")} ${configCard("Nguyên tắc bảo hiểm",[["BHXH","insSocial",DB.insuranceConfig.social],["BHYT","insHealth",DB.insuranceConfig.health],["BHTN","insUnemployment",DB.insuranceConfig.unemployment],["Mức trần","insCeiling",DB.insuranceConfig.ceiling]],"saveInsuranceConfig")}`,"insuranceConfig");}
function saveInsuranceConfig(){DB.insuranceConfig={social:document.getElementById("insSocial").value,health:document.getElementById("insHealth").value,unemployment:document.getElementById("insUnemployment").value,ceiling:document.getElementById("insCeiling").value};addAudit("Updated Insurance Configuration","INSURANCE_CONFIG");toast("Đã lưu Insurance Configuration");adminInsuranceConfig();}
function adminAudit(){app.innerHTML=shell(`${pageHead("Audit Log","Theo dõi thao tác quản trị và nghiệp vụ")}
${table(["ID","Thời gian","User","Role","Action","Target","Result"],DB.auditLogs.map(x=>`<tr><td>${x.id}</td><td>${x.time}</td><td>${x.user}</td><td>${roleLabel(x.role)}</td><td>${x.action}</td><td>${x.target}</td><td>${badge(x.result)}</td></tr>`).join(""))}`,"audit");}
function showNotifications(){const role=DB.currentUser.role,ns=DB.notifications.filter(n=>n.to===role);ns.forEach(n=>n.read=true);showModal("Thông báo",ns.length?ns.map(n=>`<div class="request-row"><div><b>${n.title}</b><span>${n.message} • ${n.time}</span></div></div>`).join(""):'<div class="empty">Không có thông báo.</div>');}
function showModal(title,body){document.getElementById("overlay").innerHTML=`<div class="modal-backdrop" onclick="if(event.target===this)closeModal()"><div class="modal"><div class="modal-head"><h3>${title}</h3><button class="close" onclick="closeModal()">×</button></div>${body}</div></div>`;}
function closeModal(){const o=document.getElementById("overlay");if(o)o.innerHTML="";}
function toast(msg){const old=document.querySelector(".toast");if(old)old.remove();const el=document.createElement("div");el.className="toast";el.textContent=msg;document.body.appendChild(el);setTimeout(()=>el.remove(),2600);}
function go(page){
const r=DB.currentUser?.role;
const maps={
Employee:{dashboard:employeeDashboard,profile:employeeProfile,attendance:employeeAttendance,leave:employeeLeave,overtime:employeeOvertime,payslip:employeePayslip},
Manager:{dashboard:managerDashboard,employees:managerEmployees,attendance:managerAttendance,leave:managerLeave,overtime:managerOvertime,approvals:managerApprovals},
HR:{dashboard:hrDashboard,employees:hrEmployees,contracts:hrContracts,onboarding:hrOnboarding,attendance:hrAttendance,leave:hrLeave,overtime:hrOvertime,payroll:hrPayroll,payslip:hrPayslip,reports:hrReports},
Admin:{dashboard:adminDashboard,users:adminUsers,roles:adminRoles,otConfig:adminOtConfig,taxConfig:adminTaxConfig,insuranceConfig:adminInsuranceConfig,audit:adminAudit}
};
if(maps[r]?.[page])return maps[r][page]();
toast("Bạn không có quyền truy cập trang này");
}
login();