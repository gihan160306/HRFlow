const DB = {
  currentUser: null,

  users: [
    {id:"USR001", name:"Nguyễn Minh Anh", email:"hr@company.com", password:"123456", role:"HR", initials:"MA", status:"Active"},
    {id:"USR002", name:"Trần Minh Khoa", email:"manager@company.com", password:"123456", role:"Manager", initials:"MK", status:"Active"},
    {id:"USR003", name:"Lê Thu Hà", email:"employee@company.com", password:"123456", role:"Employee", initials:"LH", status:"Active"},
    {id:"USR004", name:"Phạm Gia Huy", email:"admin@company.com", password:"123456", role:"Admin", initials:"PH", status:"Active"}
  ],

  employees: [
    {id:"EMP001",name:"Nguyễn Minh Anh",department:"Human Resources",position:"HR Specialist",salary:"18,000,000",status:"Active",email:"hr@company.com",phone:"0901000001",joinDate:"05/01/2024",manager:"Phạm Gia Huy",leaveBalance:12},
    {id:"EMP002",name:"Trần Minh Khoa",department:"Engineering",position:"Software Engineer",salary:"22,000,000",status:"Active",email:"manager@company.com",phone:"0901000002",joinDate:"10/03/2023",manager:"Phạm Gia Huy",leaveBalance:8},
    {id:"EMP003",name:"Lê Thu Hà",department:"Marketing",position:"Marketing Executive",salary:"16,500,000",status:"Active",email:"employee@company.com",phone:"0901000003",joinDate:"15/06/2024",manager:"Trần Minh Khoa",leaveBalance:10},
    {id:"EMP004",name:"Phạm Gia Huy",department:"Engineering",position:"Backend Developer",salary:"24,000,000",status:"Active",email:"admin@company.com",phone:"0901000004",joinDate:"02/02/2022",manager:"Nguyễn Minh Anh",leaveBalance:6},
    {id:"EMP005",name:"Võ Ngọc Mai",department:"Finance",position:"Accountant",salary:"17,500,000",status:"Inactive",email:"mai@company.com",phone:"0901000005",joinDate:"12/09/2021",manager:"Nguyễn Minh Anh",leaveBalance:4},
    {id:"EMP006",name:"Đỗ Ngọc Lan",department:"Engineering",position:"Frontend Developer",salary:"20,500,000",status:"Active",email:"lan@company.com",phone:"0901000006",joinDate:"08/04/2025",manager:"Trần Minh Khoa",leaveBalance:10},
    {id:"EMP007",name:"Nguyễn Hoàng Nam",department:"Engineering",position:"QA Engineer",salary:"19,000,000",status:"Active",email:"nam@company.com",phone:"0901000007",joinDate:"20/07/2025",manager:"Trần Minh Khoa",leaveBalance:5}
  ],

  /* =========================
     PTO / LEAVE REQUESTS
     Status:
     Draft / Pending / Approved / Rejected / Cancelled
     ========================= */

  leaveRequests: [
    {
      id:"PTO001",
      employee:"Trần Minh Khoa",
      employeeId:"EMP002",
      type:"Annual Leave",
      from:"20/09/2026",
      to:"21/09/2026",
      days:2,
      status:"Pending",
      reason:"Việc cá nhân"
    },

    {
      id:"PTO002",
      employee:"Lê Thu Hà",
      employeeId:"EMP003",
      type:"Sick Leave",
      from:"19/09/2026",
      to:"19/09/2026",
      days:1,
      status:"Approved",
      reason:"Nghỉ ốm"
    },

    {
      id:"PTO003",
      employee:"Phạm Gia Huy",
      employeeId:"EMP004",
      type:"Annual Leave",
      from:"25/09/2026",
      to:"27/09/2026",
      days:3,
      status:"Pending",
      reason:"Nghỉ phép năm"
    },

    {
      id:"PTO004",
      employee:"Đỗ Ngọc Lan",
      employeeId:"EMP006",
      type:"Annual Leave",
      from:"29/09/2026",
      to:"30/09/2026",
      days:2,
      status:"Draft",
      reason:"Nghỉ việc cá nhân"
    },

    {
      id:"PTO005",
      employee:"Nguyễn Hoàng Nam",
      employeeId:"EMP007",
      type:"Annual Leave",
      from:"10/09/2026",
      to:"10/09/2026",
      days:1,
      status:"Rejected",
      reason:"Đã đủ nhân sự trong ngày"
    },

    {
      id:"PTO006",
      employee:"Võ Ngọc Mai",
      employeeId:"EMP005",
      type:"Annual Leave",
      from:"05/09/2026",
      to:"05/09/2026",
      days:1,
      status:"Cancelled",
      reason:"Đã hủy yêu cầu"
    }
  ],

  /* =========================
     OT SCHEDULE
     Employee KHÔNG tự tạo ca OT.
     HR / Manager tạo lịch OT trước.
     ========================= */

  otSchedules: [
    {
      id:"OT001",
      date:"19/09/2026",
      time:"18:00 - 21:00",
      department:"Engineering",
      slots:"8/10",
      status:"Open",
      rate:"150%"
    },

    {
      id:"OT002",
      date:"22/09/2026",
      time:"18:00 - 20:00",
      department:"Marketing",
      slots:"4/6",
      status:"Open",
      rate:"150%"
    },

    {
      id:"OT003",
      date:"25/09/2026",
      time:"18:00 - 22:00",
      department:"Engineering",
      slots:"0/8",
      status:"Open",
      rate:"200%"
    }
  ],

  team: [
    {id:"EMP002",name:"Trần Minh Khoa",department:"Engineering",position:"Software Engineer",attendance:"Present",leaveBalance:8,status:"Active"},
    {id:"EMP004",name:"Phạm Gia Huy",department:"Engineering",position:"Backend Developer",attendance:"Late",leaveBalance:6,status:"Active"},
    {id:"EMP006",name:"Đỗ Ngọc Lan",department:"Engineering",position:"Frontend Developer",attendance:"Present",leaveBalance:10,status:"Active"},
    {id:"EMP007",name:"Nguyễn Hoàng Nam",department:"Engineering",position:"QA Engineer",attendance:"Absent",leaveBalance:5,status:"Active"}
  ],

  managerApprovals: [
    {
      id:"PTO004",
      employee:"Trần Minh Khoa",
      employeeId:"EMP002",
      type:"Annual Leave",
      from:"23/09/2026",
      to:"24/09/2026",
      days:2,
      status:"Pending",
      reason:"Việc gia đình"
    },

    {
      id:"PTO005",
      employee:"Phạm Gia Huy",
      employeeId:"EMP004",
      type:"Annual Leave",
      from:"28/09/2026",
      to:"28/09/2026",
      days:1,
      status:"Pending",
      reason:"Việc cá nhân"
    }
  ],

  /* =========================
     OT REGISTRATION
     Employee chỉ đăng ký vào
     lịch OT đã được tạo.
     ========================= */

  otRegistrations: [
    {
      id:"OTR001",
      employee:"Trần Minh Khoa",
      employeeId:"EMP002",
      schedule:"OT001",
      date:"19/09/2026",
      time:"18:00 - 21:00",
      hours:3,
      status:"Pending",
      reason:"Hoàn thành sprint"
    },

    {
      id:"OTR002",
      employee:"Phạm Gia Huy",
      employeeId:"EMP004",
      schedule:"OT001",
      date:"19/09/2026",
      time:"18:00 - 21:00",
      hours:3,
      status:"Approved",
      reason:"Hỗ trợ release"
    },

    {
      id:"OTR003",
      employee:"Lê Thu Hà",
      employeeId:"EMP003",
      schedule:"OT002",
      date:"22/09/2026",
      time:"18:00 - 20:00",
      hours:2,
      status:"Pending",
      reason:"Chuẩn bị campaign"
    },

    {
      id:"OTR004",
      employee:"Đỗ Ngọc Lan",
      employeeId:"EMP006",
      schedule:"OT003",
      date:"25/09/2026",
      time:"18:00 - 22:00",
      hours:4,
      status:"Rejected",
      reason:"Không phù hợp kế hoạch nhân sự"
    },

    {
      id:"OTR005",
      employee:"Nguyễn Hoàng Nam",
      employeeId:"EMP007",
      schedule:"OT003",
      date:"25/09/2026",
      time:"18:00 - 22:00",
      hours:4,
      status:"Cancelled",
      reason:"Nhân viên đã hủy đăng ký"
    },

    {
      id:"OTR006",
      employee:"Nguyễn Minh Anh",
      employeeId:"EMP001",
      schedule:"OT002",
      date:"22/09/2026",
      time:"18:00 - 20:00",
      hours:2,
      status:"Draft",
      reason:"Hỗ trợ HR"
    }
  ],

  approvalHistory: [
    {
      id:"APR001",
      employee:"Lê Thu Hà",
      type:"PTO",
      request:"Sick Leave",
      date:"19/09/2026",
      decision:"Approved",
      processed:"18/09/2026"
    },

    {
      id:"APR002",
      employee:"Phạm Gia Huy",
      type:"OT",
      request:"OT001",
      date:"19/09/2026",
      decision:"Approved",
      processed:"18/09/2026"
    }
  ],

  attendance: [
    {date:"18/09/2026",employee:"Nguyễn Minh Anh",checkin:"08:02",checkout:"17:05",hours:"8h 03m",status:"Present"},
    {date:"18/09/2026",employee:"Trần Minh Khoa",checkin:"08:17",checkout:"17:10",hours:"7h 53m",status:"Late"},
    {date:"18/09/2026",employee:"Lê Thu Hà",checkin:"07:58",checkout:"17:00",hours:"8h 02m",status:"Present"},
    {date:"18/09/2026",employee:"Phạm Gia Huy",checkin:"08:04",checkout:"16:40",hours:"7h 36m",status:"Early Leave"}
  ],

  /* =========================
     PAYROLL
     Workflow:
     Draft → Calculated → Approved → Locked
     ========================= */

  payroll: [
    {
      id:"PAY001",
      employeeId:"EMP001",
      name:"Nguyễn Minh Anh",
      period:"09/2026",
      gross:"18,000,000",
      insurance:"1,890,000",
      tax:"410,000",
      ot:"0",
      net:"15,700,000",
      status:"Draft"
    },

    {
      id:"PAY002",
      employeeId:"EMP002",
      name:"Trần Minh Khoa",
      period:"09/2026",
      gross:"22,900,000",
      insurance:"2,289,000",
      tax:"1,020,000",
      ot:"900,000",
      net:"19,591,000",
      status:"Calculated"
    },

    {
      id:"PAY003",
      employeeId:"EMP003",
      name:"Lê Thu Hà",
      period:"09/2026",
      gross:"16,500,000",
      insurance:"1,732,500",
      tax:"280,000",
      ot:"0",
      net:"14,487,500",
      status:"Approved"
    },

    {
      id:"PAY004",
      employeeId:"EMP004",
      name:"Phạm Gia Huy",
      period:"08/2026",
      gross:"25,200,000",
      insurance:"2,520,000",
      tax:"1,200,000",
      ot:"1,200,000",
      net:"21,480,000",
      status:"Locked"
    }
  ],

  contracts: [
    {
      id:"CTR001",
      employeeId:"EMP001",
      employee:"Nguyễn Minh Anh",
      type:"Indefinite",
      start:"05/01/2024",
      end:"Không thời hạn",
      status:"Active",
      salary:"18,000,000"
    },

    {
      id:"CTR002",
      employeeId:"EMP002",
      employee:"Trần Minh Khoa",
      type:"Indefinite",
      start:"10/03/2023",
      end:"Không thời hạn",
      status:"Active",
      salary:"22,000,000"
    },

    {
      id:"CTR003",
      employeeId:"EMP003",
      employee:"Lê Thu Hà",
      type:"Fixed-term",
      start:"15/06/2024",
      end:"15/06/2027",
      status:"Active",
      salary:"16,500,000"
    },

    {
      id:"CTR004",
      employeeId:"EMP004",
      employee:"Phạm Gia Huy",
      type:"Indefinite",
      start:"02/02/2022",
      end:"Không thời hạn",
      status:"Active",
      salary:"24,000,000"
    }
  ],

  onboarding: [
    {
      id:"ONB001",
      employee:"Lê Thu Hà",
      employeeId:"EMP003",
      start:"15/06/2024",
      progress:100,
      status:"Completed",
      items:"Tài khoản, Email, Laptop, Orientation"
    },

    {
      id:"ONB002",
      employee:"Đỗ Ngọc Lan",
      employeeId:"EMP006",
      start:"08/04/2025",
      progress:75,
      status:"In Progress",
      items:"Tài khoản, Email, Laptop"
    },

    {
      id:"ONB003",
      employee:"Nguyễn Hoàng Nam",
      employeeId:"EMP007",
      start:"20/07/2025",
      progress:50,
      status:"In Progress",
      items:"Tài khoản, Email"
    }
  ],

  ptoBalances: [
    {employeeId:"EMP001",employee:"Nguyễn Minh Anh",annual:12,used:3,remaining:9},
    {employeeId:"EMP002",employee:"Trần Minh Khoa",annual:12,used:4,remaining:8},
    {employeeId:"EMP003",employee:"Lê Thu Hà",annual:12,used:2,remaining:10},
    {employeeId:"EMP004",employee:"Phạm Gia Huy",annual:12,used:6,remaining:6},
    {employeeId:"EMP006",employee:"Đỗ Ngọc Lan",annual:12,used:2,remaining:10},
    {employeeId:"EMP007",employee:"Nguyễn Hoàng Nam",annual:12,used:7,remaining:5}
  ],

  notifications: [
    {
      id:"N001",
      to:"Employee",
      title:"Lịch OT mới",
      message:"HR đã tạo lịch OT Engineering ngày 25/09/2026.",
      time:"19/09/2026 09:10",
      read:false
    },

    {
      id:"N002",
      to:"Manager",
      title:"Có đăng ký OT mới",
      message:"Lê Thu Hà vừa đăng ký OT002, đang chờ duyệt.",
      time:"19/09/2026 09:20",
      read:false
    },

    {
      id:"N003",
      to:"HR",
      title:"PTO đã được duyệt",
      message:"Đơn PTO của Lê Thu Hà đã Approved.",
      time:"19/09/2026 09:25",
      read:false
    }
  ],

  roles: [
    {
      role:"Employee",
      description:"Xem hồ sơ, chấm công, PTO, OT, payslip"
    },

    {
      role:"Manager",
      description:"Quản lý team và phê duyệt PTO/OT"
    },

    {
      role:"HR",
      description:"Quản trị nhân sự, OT schedule, payroll, payslip"
    },

    {
      role:"Admin",
      description:"Tài khoản, role/permission, cấu hình, audit"
    }
  ],

  permissions: [
    {
      role:"Employee",
      dashboard:true,
      profile:true,
      attendance:true,
      leave:true,
      overtime:true,
      payslip:true
    },

    {
      role:"Manager",
      dashboard:true,
      employees:true,
      attendance:true,
      leave:true,
      overtime:true,
      approvals:true
    },

    {
      role:"HR",
      dashboard:true,
      employees:true,
      attendance:true,
      leave:true,
      overtime:true,
      payroll:true,
      payslip:true,
      contracts:true,
      onboarding:true,
      pto:true,
      otSchedule:true
    },

    {
      role:"Admin",
      dashboard:true,
      users:true,
      roles:true,
      otConfig:true,
      taxConfig:true,
      insuranceConfig:true,
      audit:true
    }
  ],

  otConfig:{
    weekdayRate:"150%",
    weekendRate:"200%",
    holidayRate:"300%",
    maxHours:"4",
    approvalRequired:true
  },

  taxConfig:{
    personalDeduction:"11,000,000",
    dependentDeduction:"4,400,000",
    method:"Progressive"
  },

  insuranceConfig:{
    social:"8%",
    health:"1.5%",
    unemployment:"1%",
    ceiling:"36,000,000"
  },

  auditLogs:[
    {
      id:"LOG001",
      time:"19/09/2026 09:25",
      user:"Nguyễn Minh Anh",
      role:"HR",
      action:"Viewed Payroll",
      target:"PAYROLL",
      result:"Success"
    },

    {
      id:"LOG002",
      time:"19/09/2026 09:20",
      user:"Trần Minh Khoa",
      role:"Manager",
      action:"Approved OT",
      target:"OTR002",
      result:"Success"
    },

    {
      id:"LOG003",
      time:"19/09/2026 09:10",
      user:"Nguyễn Minh Anh",
      role:"HR",
      action:"Created OT Schedule",
      target:"OT003",
      result:"Success"
    }
  ]
};